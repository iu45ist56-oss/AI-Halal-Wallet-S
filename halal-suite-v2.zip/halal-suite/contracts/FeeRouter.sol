// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
// Buy / Sell / Convert এ fee কেটে feeWallet এ পাঠায়, বাকিটা PancakeSwap এ swap করে। শুধু owner-অনুমোদিত (হালাল) টোকেন।
// ⚠️ আসল টাকা দেওয়ার আগে Testnet এ টেস্ট ও professional audit করান।
interface IERC20{function transferFrom(address,address,uint)external returns(bool);function transfer(address,uint)external returns(bool);function approve(address,uint)external returns(bool);}
interface IR{function WETH()external pure returns(address);function getAmountsOut(uint,address[] calldata)external view returns(uint[] memory);
function swapExactETHForTokens(uint,address[] calldata,address,uint)external payable returns(uint[] memory);
function swapExactTokensForETH(uint,uint,address[] calldata,address,uint)external returns(uint[] memory);
function swapExactTokensForTokens(uint,uint,address[] calldata,address,uint)external returns(uint[] memory);}
contract FeeRouter{
IR public immutable router;address public owner;address public feeWallet;uint public feeBps=50;uint constant MAX=300;bool private lk;mapping(address=>bool) public halal;
event Fee(address indexed user,address token,uint amount);
modifier onlyOwner(){require(msg.sender==owner,"owner");_;}
modifier nr(){require(!lk,"re");lk=true;_;lk=false;}
constructor(address r,address fw){router=IR(r);owner=msg.sender;feeWallet=fw;}
function setFeeBps(uint b)external onlyOwner{require(b<=MAX,"max 3%");feeBps=b;}
function setFeeWallet(address w)external onlyOwner{require(w!=address(0));feeWallet=w;}
function setHalal(address t,bool v)external onlyOwner{halal[t]=v;}
function transferOwnership(address o)external onlyOwner{require(o!=address(0));owner=o;}
function _p(address a,address b)internal view returns(address[] memory p){address w=router.WETH();if(a==w||b==w){p=new address[](2);p[0]=a;p[1]=b;}else{p=new address[](3);p[0]=a;p[1]=w;p[2]=b;}}
function quote(address a,address b,uint amt)external view returns(uint){address[] memory p=_p(a,b);uint[] memory o=router.getAmountsOut(amt,p);return o[o.length-1];}
function buyWithBNB(address t,uint minOut,uint dl)external payable nr{require(halal[t],"not halal");uint f=msg.value*feeBps/10000;(bool ok,)=feeWallet.call{value:f}("");require(ok,"fee");emit Fee(msg.sender,address(0),f);
router.swapExactETHForTokens{value:msg.value-f}(minOut,_p(router.WETH(),t),msg.sender,dl);}
function sellForBNB(address t,uint amt,uint minOut,uint dl)external nr{require(halal[t],"not halal");require(IERC20(t).transferFrom(msg.sender,address(this),amt),"pull");uint f=amt*feeBps/10000;require(IERC20(t).transfer(feeWallet,f),"fee");emit Fee(msg.sender,t,f);
uint n=amt-f;IERC20(t).approve(address(router),n);router.swapExactTokensForETH(n,minOut,_p(t,router.WETH()),msg.sender,dl);}
function convert(address a,address b,uint amt,uint minOut,uint dl)external nr{require(halal[a]&&halal[b],"not halal");require(IERC20(a).transferFrom(msg.sender,address(this),amt),"pull");uint f=amt*feeBps/10000;require(IERC20(a).transfer(feeWallet,f),"fee");emit Fee(msg.sender,a,f);
uint n=amt-f;IERC20(a).approve(address(router),n);router.swapExactTokensForTokens(n,minOut,_p(a,b),msg.sender,dl);}
}
