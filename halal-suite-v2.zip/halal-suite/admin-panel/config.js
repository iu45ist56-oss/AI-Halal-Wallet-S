// Admin wallet এর PUBLIC address এখানে বসান (wallet-app/config.js এর ADMIN_ADDRESS এর সাথে মিলতে হবে)
window.ACFG={ADMIN_ADDRESS:"0xYOUR_ADMIN_WALLET_ADDRESS",RPC:"https://bsc-dataseed.binance.org",SYMBOL:"BNB"};
