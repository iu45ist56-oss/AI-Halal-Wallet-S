require('dotenv').config();
const express=require('express'),cors=require('cors'),nm=require('nodemailer'),bc=require('bcryptjs'),jwt=require('jsonwebtoken'),rl=require('express-rate-limit'),fs=require('fs'),cr=require('crypto');
if(!process.env.JWT_SECRET)throw Error('JWT_SECRET লাগবে (.env)');
const app=express();app.use(express.json({limit:'10kb'}));app.use(cors({origin:process.env.ALLOWED_ORIGIN||true}));app.use(rl({windowMs:60000,max:60}));
const strict=rl({windowMs:15*60000,max:15,message:{error:'অনেকবার চেষ্টা হয়েছে, পরে চেষ্টা করুন'}});
const F='db.json',db=()=>fs.existsSync(F)?JSON.parse(fs.readFileSync(F)):{users:{},otps:{}},save=d=>fs.writeFileSync(F,JSON.stringify(d));
const mail=nm.createTransport({service:'gmail',auth:{user:process.env.GMAIL_USER,pass:process.env.GMAIL_APP_PASSWORD}});
const em=e=>String(e||'').trim().toLowerCase(),okEm=e=>/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e),okPw=p=>typeof p==='string'&&p.length>=8;
async function sendOtp(e,k){const d=db(),c=String(cr.randomInt(100000,1000000));d.otps[e+k]={h:bc.hashSync(c,8),exp:Date.now()+6e5,t:0};save(d);
await mail.sendMail({from:process.env.GMAIL_USER,to:e,subject:'Halal Wallet — আপনার ভেরিফিকেশন কোড',text:`আপনার কোড: ${c}\n১০ মিনিট পর্যন্ত বৈধ। এই কোড কারো সাথে শেয়ার করবেন না।`})}
function chk(e,k,c){const d=db(),o=d.otps[e+k];if(!o||o.exp<Date.now()||o.t>=5)return false;o.t++;const ok=bc.compareSync(String(c),o.h);if(ok)delete d.otps[e+k];save(d);return ok}
const tok=e=>jwt.sign({e},process.env.JWT_SECRET,{expiresIn:'7d'});
const au=(q,s,n)=>{try{q.u=jwt.verify((q.headers.authorization||'').slice(7),process.env.JWT_SECRET).e;n()}catch(x){s.status(401).json({error:'আগে লগইন করুন'})}};
const wrap=f=>(q,s)=>f(q,s).catch(x=>{console.error(x);s.status(500).json({error:'সার্ভার ত্রুটি'})});
// Signup / Reset এর জন্য কোড পাঠানো
app.post('/auth/otp',strict,wrap(async(q,s)=>{const e=em(q.body.email),p=q.body.purpose;if(!okEm(e)||!['signup','reset'].includes(p))return s.status(400).json({error:'ভুল ইনপুট'});
const ex=!!db().users[e];if((p==='signup'&&!ex)||(p==='reset'&&ex))await sendOtp(e,p);s.json({ok:true})}));
app.post('/auth/signup',strict,wrap(async(q,s)=>{const e=em(q.body.email);if(!okEm(e)||!okPw(q.body.password))return s.status(400).json({error:'Password কমপক্ষে ৮ অক্ষর'});
if(!chk(e,'signup',q.body.otp))return s.status(400).json({error:'কোড ভুল বা মেয়াদ শেষ'});const d=db();if(d.users[e])return s.status(400).json({error:'আগে থেকেই আছে'});
d.users[e]={h:bc.hashSync(q.body.password,12),at:Date.now()};save(d);s.json({token:tok(e)})}));
// Login = password + ইমেইলে আসা কোড (কোড ছাড়া কেউ ঢুকতে পারবে না)
app.post('/auth/login',strict,wrap(async(q,s)=>{const e=em(q.body.email),u=db().users[e];if(!u||!bc.compareSync(String(q.body.password||''),u.h))return s.status(400).json({error:'ইমেইল বা Password ভুল'});await sendOtp(e,'login');s.json({ok:true})}));
app.post('/auth/login-verify',strict,wrap(async(q,s)=>{const e=em(q.body.email);if(!chk(e,'login',q.body.otp))return s.status(400).json({error:'কোড ভুল বা মেয়াদ শেষ'});s.json({token:tok(e)})}));
app.post('/auth/reset',strict,wrap(async(q,s)=>{const e=em(q.body.email);if(!okPw(q.body.password))return s.status(400).json({error:'Password কমপক্ষে ৮ অক্ষর'});
if(!chk(e,'reset',q.body.otp))return s.status(400).json({error:'কোড ভুল বা মেয়াদ শেষ'});const d=db();if(!d.users[e])return s.status(400).json({error:'ত্রুটি'});d.users[e].h=bc.hashSync(q.body.password,12);save(d);s.json({ok:true})}));
// AI Prediction (শুধু হালাল তালিকা; confidence সর্বোচ্চ ৭৫%)
const IDS={bitcoin:'BTC',ethereum:'ETH',binancecoin:'BNB','the-open-network':'TON',chainlink:'LINK'},H=[['৫ মি',5/60],['৩০ মি',.5],['১ ঘন্টা',1],['১ দিন',24],['১৫ দিন',360],['৩০ দিন',720]];
const ema=(a,n)=>{const k=2/(n+1);return a.reduce((e,x)=>e+k*(x-e))},sum=a=>a.reduce((s,x)=>s+x,0);
function model(p){const r=[];for(let i=1;i<p.length;i++)r.push(Math.log(p[i]/p[i-1]));const mu=sum(r)/r.length,sd=Math.sqrt(Math.max(sum(r.map(x=>x*x))/r.length-mu*mu,1e-10));
const trend=ema(p.slice(-24),6)/ema(p.slice(-168),48)-1;let up=0,dn=0;r.slice(-14).forEach(x=>x>0?up+=x:dn-=x);const rsi=100-100/(1+up/(dn||1e-9));
let d=(sum(r.slice(-24))/24*.4+sum(r.slice(-168))/168*.4+trend/24*.2)*.35;if(rsi>70)d*=.5;if(rsi<30)d=Math.abs(d)*.5;
return{rsi:Math.round(rsi),h:H.map(([l,h])=>{const e=d*h,v=sd*Math.sqrt(h);return{l,pct:+(e*100).toFixed(2),lo:+((e-v)*100).toFixed(2),hi:+((e+v)*100).toFixed(2),conf:Math.round(Math.max(30,Math.min(75,72-v*250)))}})}}
let C={t:0,v:null};
app.get('/predict',au,wrap(async(q,s)=>{if(C.v&&Date.now()-C.t<18e4)return s.json(C.v);const items=[];
for(const id of Object.keys(IDS)){const j=await(await fetch(`https://api.coingecko.com/api/v3/coins/${id}/market_chart?vs_currency=usd&days=30`)).json();if(!j.prices)continue;const p=j.prices.map(x=>x[1]);items.push({sym:IDS[id],price:p[p.length-1],...model(p)})}
if(!items.length)return s.status(503).json({error:'মার্কেট ডেটা পাওয়া যায়নি'});C={t:Date.now(),v:{items,note:'অনুমান মাত্র, গ্যারান্টি নয়'}};s.json(C.v)}));
// Help bot
const SYS='তুমি Halal Wallet এর বাংলা সহায়ক। ছোট ও সহজ উত্তর দাও। কখনো লাভের নিশ্চয়তা দেবে না। কখনো Recovery phrase বা Private key চাইবে না। শুধু হালাল spot ট্রেডিং, futures/leverage/staking/lending নেই।';
const FAQ=[[/otp|কোড|code/i,'কোড না এলে Spam ফোল্ডার দেখুন, ১ মিনিট পর আবার চেষ্টা করুন। কোড ১০ মিনিট বৈধ।'],[/forgot|ভুলে|password|পাসওয়ার্ড/i,'লগইন পেজে "Password ভুলে গেছি" চাপুন, ইমেইলে কোড আসবে, কোড দিয়ে নতুন Password দিন।'],[/fee|ফি/i,'প্রতি লেনদেনে platform fee আর blockchain gas লাগে। gas নেটওয়ার্ক নেয়, platform fee সেটিং অনুযায়ী।'],[/recovery|phrase|key|কী/i,'Recovery phrase কাগজে লিখে রাখুন, কাউকে দেবেন না। আমরা কখনো চাই না। হারালে wallet ফেরত পাওয়া যাবে না।'],[/predict|দাম|বাড়/i,'Prediction একটি অনুমান, নিশ্চয়তা নয়। Confidence ৭৫% এর বেশি হয় না। নিজের ঝুঁকি বুঝে সিদ্ধান্ত নিন।'],[/halal|হালাল/i,'শুধু spot ট্রেড, তালিকাভুক্ত টোকেন। futures, leverage, staking, lending নেই।']];
app.post('/help',rl({windowMs:60000,max:15}),wrap(async(q,s)=>{const m=String(q.body.message||'').slice(0,500);
if(process.env.ANTHROPIC_API_KEY){try{const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:process.env.ANTHROPIC_MODEL||'claude-sonnet-5-5',max_tokens:400,system:SYS,messages:[{role:'user',content:m}]})});const j=await r.json();if(j.content&&j.content[0])return s.json({reply:j.content[0].text})}catch(x){}}
const f=FAQ.find(x=>x[0].test(m));s.json({reply:f?f[1]:'আমি ঠিক বুঝিনি। কোড, Password, fee, recovery phrase, prediction বা হালাল নিয়ে জিজ্ঞেস করুন।'})}));
app.listen(process.env.PORT||3000,()=>console.log('running'));
