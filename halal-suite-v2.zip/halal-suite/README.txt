Halal Suite v2 — ৩টা আলাদা অংশ
1) wallet-app/   ইউজারদের অ্যাপ (Vercel/Netlify এ static deploy; admin কিছু নেই)
2) admin-panel/  শুধু আপনার জন্য, সম্পূর্ণ আলাদা (নিজের Password নিজে সেট করবেন)
3) backend/      ইমেইল কোড (OTP) লগইন, Password রিসেট, Prediction, Help bot (Node 18+; Render/Railway/VPS এ চলবে)
4) contracts/FeeRouter.sol  Buy/Sell/Convert এ fee কাটার কন্ট্রাক্ট (Remix দিয়ে deploy)

ধাপ:
A. backend: cd backend && npm install && .env.example কপি করে .env বানান (Gmail App Password লাগবে) && npm start
B. contracts: Remix এ FeeRouter deploy করুন। constructor: router=PancakeSwap V2 Router (BSC: 0x10ED43C718714eb63d5aA57B78B54704E256024E), feeWallet=আপনার admin address।
   তারপর setHalal(tokenAddress,true) দিয়ে হালাল টোকেন চালু করুন। আগে BSC Testnet এ টেস্ট করুন।
C. wallet-app/config.js এ API, ADMIN_ADDRESS, FEE_ROUTER বসান; admin-panel/config.js এ ADMIN_ADDRESS বসান।
D. দুই ফোল্ডার আলাদা প্রজেক্ট হিসেবে Vercel এ আপলোড করুন।
